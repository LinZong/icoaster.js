import UserAccount from '../Persistence/Model/UserAccount'
const GenerateUID = () => Math.random().toString(36).substr(2, 11)

const Login = (OpenID: string, SessionKey: string) => {
    const user = new UserAccount({OpenID : OpenID, SessionKey : SessionKey, UID : GenerateUID()})
    user.save()
}
export { Login }