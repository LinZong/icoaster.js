
import { Table, Column, Model, HasMany, PrimaryKey } from 'sequelize-typescript';

@Table({ tableName: "user_account" })
class UserAccount extends Model<UserAccount>
{
    @Column({field : 'openid',primaryKey : true})
    OpenID: string

    @Column({field : 'session_key'})
    SessionKey: string

    @Column({field : 'uid'})
    UID: string
}

export default UserAccount